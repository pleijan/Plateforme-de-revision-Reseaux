---
title: 'Manuel Utilisateur : Outil pédagogique pour le module de réseau'
author: ''
date: "20/03/2021"
output:
  pdf_document:
    number_sections: yes
  word_document:
    toc: yes
  html_document:
    toc: yes
    df_print: paged
---
Ce projet a été réaliser dans le cadre d'un projet tutoré pour l'Iut de Vélizy. Il a été tutoré par M.Hoguin.
C'est un outil qui vous aidera à mieux comprendre par des applications et des cours le module réseau de première année.
En effet, vous pourrez apprendre à :

- Traduire une adresse IP de binaire à décimal ou inversement,
- Traduire une adresse IP d'héxadécimal à décimal ou inversement,
- Diviser un réseau en sous-réseaux avec la notation CIDR,
- Diviser un réseau en sous-réseaux avec la notation VLSM,
- Calculer un CRC Matriciel et Polynomial

Vous pourrez même exécuter quelques commandes réseaux comme :

- nmap
- nslookup
- tcpdump
- ping
- man

Vous pourrez éventuellement accéder au : 

- glossaire

Et si vous êtes admin, vous pouvez y ajouter des mots ainsi que modifier leurs définitions.

Chaque pages est composé d'une partie cours, et d'une partie application qui permet de tester vos résultats.
En accédant au site, vous trouverez sur la page d'accueil un menu en haut, qui permettra d'acceder aux différentes fonctionnalités énoncé précedemment.


![Le menu](menu.png)

De même pour toute les petites images qui se situent plus bas dans cette page.

![Images permettant d'accéder aux fonctionnalités](imgMenu.png)

\newpage

# Traduire une adresse IP de binaire à décimal ou inversement

Pour accéder à cette fonctionnalité, cliquez sur "**Conversion adresses IP**" puis "**Binaire -> Décimal**".
Ou bien cliquez sur l'image correspondante à partir de l'accueil.

Sur cette page vous pourrez effectuer des traductions d'adresses IP de binaire à décimal et inversement.

Tout d'abord, vous pouvez accéder au cours via le lien pointé par la flèche bleu (voir image ci-dessous) et une petite fenêtre apparaîtra.
Ensuite, la première étape est d'écrire dans le champ, l'adresse IP séparer par des points. N'inscrivez pas de lettre, et écrivez une adresse IP correcte sinon une erreur apparaîtra.
Puis, choisissez votre mode de conversion grâce aux radios boutons.
Et enfin appuyer sur le bouton "**Valider**".

![](bin-dec.png)

Le résultat apparaît:

![Resultat de la traduction Décimal à binaire de l'adresse : 192.168.3.10](Resultat_bin-dec.png)

Procédez de la même façon pour la traduction de binaire à décimal.

![Exemple pour une traduction binaire](bin-dec_Ex.png)

\newpage

# Traduire une adresse IP d'héxadécimal à décimal ou inversement

Pour accéder à cette fonctionnalité, cliquez sur "**Conversion adresses IP**" puis "**Héxadécimal -> Décimal**".
Ou bien cliquez sur l'image correspondante à partir de l'accueil.

Sur cette page vous pourrez effectuer des traductions d'adresses IP d'Héxadécimal à décimal et inversement.
Vous pouvez accéder au cours via le lien pointé par la flèche bleu (voir image ci-dessous) et une petite fenêtre apparaîtra.

Tout d'abord, la première étape est d'écrire dans le champ, l'adresse IP séparer par des points. N'inscrivez pas de lettre, et écrivez une adresse IP correcte sinon une erreur apparaîtra.
Puis, choisissez votre mode de conversion grâce aux radios boutons.
Et enfin appuyer sur le bouton "**Valider**".

![](hex-dec.png)

Le résultat apparaît:

![Resultat de la traduction Décimal à binaire de l'adresse : 192.168.3.10](Resultat_hex-dec.png)

Procédez de la même façon pour la traduction héxadécimal à décimal.

![Exemple pour une traduction héxadécimal](hex-dec_Ex.png)

\newpage

# Diviser un réseau en sous-réseaux avec la notation CIDR

Pour accéder à cette fonctionnalité, cliquez sur "**Division de réseaux**" puis "**Notation CIDR**".
Ou bien cliquez sur l'image correspondante à partir de l'accueil.

Sur cette page vous pourrez diviser un réseau en sous-reseau avec la notation CIDR.
Vous pouvez accéder au cours via le lien pointé par la flèche bleu (voir image ci-dessous) et une petite fenêtre apparaîtra.

Pour diviser le réseau en sous-réseaux, il vous faut l'adresse réseau de ce réseau. Pour cela, entrez une adresse IP dans le premier champ (Voir ci-dessous).
N'inscrivez pas de lettre, et écrivez une adresse IP correcte sinon une erreur apparaîtra.

![Comment obtenir l'adresse réseau](cidr.png)


Vous obtiendrez l'adresse réseau.

![Résultat obtenu après avoir cliquer sur valider](Resultat_cidr.png)


Ensuite, il y a d'autres champs qui cette fois ci vous permettra de diviser le réseau en sous-réseau.
Tout d'abord, entrez une **adresse réseau** dans le champ correspondant. 
**Attention ! Si vous entrez une adresse machine une erreur apparaîtra.**

Ensuite, précisez le masque avec la notation CIDR (avec le slash ' / '), ou bien le masque séparer de points.
Puis, il vous faut précisez le nombre de sous-réseau avec lequel vous voulez diviser votre réseau.
Enfin, appuyer sur le bouton "**valider**".
**Attention ! Si vous demandez un nombre de sous-réseaux qui dépasse le nombre de sous-réseaux maximum que peut accueillir ce réseau, une erreur apparaîtra .**

![Diviser le réseau en sous-réseau](cidr2.png)


Différentes informations sur les sous-réseaux apparaissent, comme le nombre d'hotes disponible au total, leurs adresse de réseau, de broadcast, ainsi leurs plages d'adresses disponible.


![Resultat après avoir cliquer sur valider](Resultat_cidr2.png)


\newpage

# Diviser un réseau en sous-réseaux avec la notation VLSM

Pour accéder à cette fonctionnalité, cliquez sur "**Division de réseaux**" puis "**Notation VLSM**".
Ou bien cliquez sur l'image correspondante à partir de l'accueil.

Sur cette page vous pourrez diviser un réseau en sous-reseau avec la notation VLSM.
Vous pouvez accéder au cours via le lien pointé par la flèche bleu (voir image ci-dessous) et une petite fenêtre apparaîtra.

Pour diviser le réseau en sous-réseaux, il vous faut l'adresse réseau de ce réseau. Pour cela, entrez une adresse IP dans le premier champ (Voir ci-dessous).
N'inscrivez pas de lettre, et écrivez une adresse IP correcte sinon une erreur apparaîtra.

![Comment obtenir l'adresse réseau](vlsmRes.png)


Vous obtiendrez l'adresse réseau.

![Résultat obtenu après avoir cliquer sur valider](Resultat_vlsmRes.png)


Ensuite, il y a d'autres champs qui cette fois ci vous permettra de diviser le réseau en sous-réseau.
Tout d'abord, entrez une **adresse réseau** dans le champ correspondant. 
**Attention ! Si vous entrez une adresse machine une erreur apparaîtra.**

Ensuite, précisez le masque avec la notation CIDR (avec le slash ' / '), ou bien le masque séparer de points.
Puis, grâce au bouton add marquer avec le signe plus (' + '), vous pouvez ajouter un sous-réseau, pour pouvoir préciser le nombre d'hôtes que vous voulez sur chaque sous-réseaux.
Enfin, appuyer sur le bouton **Valider**.
**Attention ! Si vous demandez un nombre d'hôtes qui dépasse le nombre d'hôtes maximum que peut accueillir ce réseau, une erreur apparaîtra .**

![Diviser le réseau en sous-réseau](vlsm.png)


Différentes informations sur les sous-réseaux apparaissent, comme le nombre d'hotes disponible au total, leurs adresse de réseau, de broadcast, ainsi leurs plages d'adresses disponible.


![Resultat après avoir cliquer sur valider](Resultat_vlsm.png)

\newpage

# Calculer un CRC Matriciel et Polynomial

Pour accéder à cette fonctionnalité, cliquez sur "**Calcul de CRC de type ethernet**"
Ou bien cliquez sur l'image correspondante à partir de l'accueil.

Sur cette page vous pourrez calculer un CRC matriciel et polynomial.
Vous pouvez accéder au cours ainsi qu'aux vidéos via le lien pointé par les flèches bleues (voir image ci-dessous) et une petite fenêtre apparaîtra.

Commençons tout d'abord, par calculer un CRC matriciel.
**Attention ! Pour chaque champ, il ne faut que saisir des nombres binaires.**
Il faut d'abord entrer le message dans le champ correspondant.

![](crc1.png)

Puis choisir la taille de la matrice.

![](crc2.png)

Saisir la matrice génératrice.

![](crc3.png)

Et enfin cliquer sur le bouton "**Valider**".
Et le résultat apparaît.

![](Resultat_crc.png)


Passons maintenant au CRC polynomial



